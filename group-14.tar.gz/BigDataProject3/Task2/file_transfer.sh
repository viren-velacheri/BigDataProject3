#!/bin/bash
#This assumes hadoop is located 2 directories above the current directory
#Transfer files from split dataset directory into staging area, assuming it is stored in root as "/split-dataset" and staging is stored in root as "/staging"
for i in {1..1127}
do
	../../hadoop-3.3.1/bin/hadoop fs -mv /split-dataset/$i.csv /staging
	sleep 5
done