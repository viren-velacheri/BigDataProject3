#!/bin/bash

# Input argument for hdfs output directory location
# This assumes spark is located 2 directories above the current directory and staging directory is in hdfs root directory named "staging"
# Run ./file_transfer.sh in a separate shell after this

../../spark-3.2.1-bin-hadoop3.2/bin/spark-submit task2.py hdfs://10.10.1.1:9000/staging $1