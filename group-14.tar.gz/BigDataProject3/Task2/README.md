## Task 2 Instructions

Please ensure that the split-dataset directory has been transferred to hdfs, and the appopriate staging hdfs directory has been created to begin transfer of files named "staging". If the staging directory already exists, please make sure to empty it before proceeding. Please also be sure to create the "/checkpoints" hdfs directory (be sure to empty it if already exists).

The command to run task 2 is as follows:

<b> ./run.sh output_directory </b>

Example: ./run.sh hdfs://10.10.1.1:9000/Task2Output

Next, please run the following command in another terminal to execute another shell script that will begin transferring data files to staging every 5 seconds:

<b> ./file_transfer.sh </b>

NOTE: We are assuming that both Hadoop and Spark are located 2 directories above the current directory. Please also make sure that the split-dataset directory is placed in the root hdfs directory (as "/split-dataset") along with the staging directory (as "/staging"). Once all output is written to hdfs and file transfer completes, please use CTRL+C to terminate the program once it starts to hang. Please also ensure that a checkpoints directory is created beforehand within hdfs in the root directory (as in "/checkpoints").