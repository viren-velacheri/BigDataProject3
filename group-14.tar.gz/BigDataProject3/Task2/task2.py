from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,IntegerType,TimestampType,StringType
import sys

# read in arguments - staging directory in hdfs to listen to and output directory in hdfs to write to
listen_dir = sys.argv[1]
output_file = sys.argv[2]

# create SparkSession
spark = SparkSession.builder.appName("Streaming").getOrCreate()

# define schema (structure) of split-dataset so that column names and types can be assigned when it is read in
userSchema = StructType().add("userA", IntegerType()).add("userB",IntegerType()).add("timestamp",TimestampType()).add("interaction",StringType())
# read in split-dataset using input argument and pre-defined schema as CSV
data = spark.readStream.option("sep", ",").schema(userSchema).csv(listen_dir)

# only want unique user IDs of recipients of mentions which is the userB column
mentions = data.select("userB").filter(data.interaction == "MT").distinct()

# use structured streaming to write output to output path in append mode (CSV does not support complete mode)
# display top 100 rows untruncated and run until termination (in our case CTRL+C)
# provide checkpoint location and trigger query to run every 10 seconds (coalesces to 1 file each time)
query = mentions.coalesce(1) \
    .writeStream \
    .format("csv") \
    .option("path",output_file) \
    .option("checkpointLocation", "hdfs://10.10.1.1:9000/checkpoints") \
    .trigger(processingTime='10 seconds') \
    .start() \
    .awaitTermination()